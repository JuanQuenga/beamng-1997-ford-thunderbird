1997 Ford Thunderbird LX experimental prototype
V6 and V8 configurations. Target BeamNG 0.40.x.
No in-game test has been performed. RLS runtime compatibility is unverified.
Leave this ZIP compressed and put it in the active BeamNG user folder/mods.
Test in Freeroam, then a disposable RLS career before using an existing save.
See documentation/README.md and documentation/TESTING.md.
